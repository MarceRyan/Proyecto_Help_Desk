const BASEURL = `${window.location.origin}/Help_Desk_Muni/helpdesk`;
export {
    BASEURL,
};

